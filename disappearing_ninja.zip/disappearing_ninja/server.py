from flask import Flask, redirect, render_template, request

disappearing_ninja = Flask(__name__)

@disappearing_ninja.route('/')
def landing_page():
	return render_template("index.html")

@disappearing_ninja.route('/ninja')
def all_turtles():
	return render_template("all_turtles.html")

@disappearing_ninja.route('/ninja/<color>')
def select_turtles(color):
	print color

	return render_template("select_turtles.html", color2=color)

disappearing_ninja.run(debug=True)